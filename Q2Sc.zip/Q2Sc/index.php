<?php
session_start();
?>
<html>
<head>
<title>User Login</title>
</head>
<body>

<?php
if(isset($_SESSION["id"])) 
{
?><div align=center><h1>
Welcome <?php echo $_SESSION["uname"]; ?>. Click here to <a href="logout.php" tite="Logout"><br />Logout.</h1>
</a></div>
<?php
}else echo "<h1>Session Expired</h1>";
?>
</body>
</html>
