<?php
    session_start();
    include("validator.php");
    $_SESSION['token'] = md5(uniqid(mt_rand(), true));  
    $token = $_SESSION['token'];      //CSRF Tokens
    //$token = filter_input(INPUT_POST, 'token', FILTER_SANITIZE_STRING);
    $message="";
    if(count($_POST)>0) 
    {
        
        $connection = mysqli_connect('127.0.0.1:3306','root','','secure_coding') or die('Unable To connect');
        $uname = $_POST['username'];
        $password = $_POST['password'];
        $Checkuname = new Validator("$uname");
        $Checkpass = new Validator("$password");
        $uname = preg_replace('#<script(.*?)>(.*?)</script>(.*?)#is', '', $uname);
        $password = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $password);
        $ProhibitedWords = array('UNION', 'SET', 'ALL', 'INTERSECTION', 'NULL');
        $replacements = array('', '', '', '', '');        
        $uname = str_replace($ProhibitedWords, $replacements, $uname);
        $password = str_replace($ProhibitedWords, $replacements, $password);
        $uname = mysqli_real_escape_string($connection, $uname);
        $password = mysqli_real_escape_string($connection, $password);
        if($Checkuname->chkAlpha() and $Checkpass->chkAlpha())
        {
            $uname = strip_tags("$uname");
            $user = strip_tags("$uname");
            $password = strip_tags("$password");
            $uname = md5(htmlentities(mysqli_real_escape_string($connection, $uname), ENT_QUOTES, 'UTF-8'));
            $password = md5(htmlentities(mysqli_real_escape_string($connection, $password), ENT_QUOTES, 'UTF-8'));
            if (!$token || $token !== $_SESSION['token']) 
            {    
                header($_SERVER['SERVER_PROTOCOL'] . ' 405 Method Not Allowed');
                exit;
            } 
            else 
            {
                if (!stripos ($uname, "script") and !stripos ($password, "script"))
                { 
                    $query=mysqli_query($connection,"SELECT * FROM users WHERE username ='$uname' AND password ='$password'") or die("Query Unsuccessfull:".mysqli_error($connection));
                    $num_rows=mysqli_num_rows($query);
                    $row = mysqli_fetch_array($query);
                    if($num_rows > 0)
                    {
                        $_SESSION["id"] = $row['id'];
                        $_SESSION["uname"] = $user;
                        $_SESSION["timein"] = time();
                        header("Location: index.php?id=".str_replace($ProhibitedWords, $replacements, strip_tags(htmlspecialchars(md5($_SESSION["id"].$_SESSION["uname"].$_SESSION["timein"].$_SESSION['token'])))));
                    } 
                    else 
                    {
                        $message = "Invalid Username or Password!";
                    }
           
                }
            }      
        }
        else
        {
            $message="Special Characters '#' '-' 'quotes' '\' '<' '>' '/' are Not Allowed" ;
        } 
    }
?>
<html>
<head>
<title>User Login</title>

</head>
<body bgcolor="#DAF7A6">
<div align="center">
<form name="frmUser" method="post" action="" align="center">

<h2 align="center">Enter Login Details</h2>

 <input type="text" name="username" placeholder="Username" required>
 <br><br>

<input type="password" name="password" placeholder="Password" required>
<br><br>
<input type="hidden" name="user_token" value=<?php echo $token; ?> >
<input type="submit" name="submit" value="Submit">
<input type="reset">
<br /><br />
<div class="message"><?php if($message!="") { echo "<font color=red>$message</font>"; } ?></div>
</form>
</div>
</body>
</html>
